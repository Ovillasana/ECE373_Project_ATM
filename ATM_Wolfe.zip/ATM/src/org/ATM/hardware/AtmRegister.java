package org.ATM.hardware;

import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.ATM.people.User;

public class AtmRegister extends JFrame {

	private static final long serialVersionUID = -5323104247007829603L;
	private JPanel contentPane;
	private ImageIcon imageIcon;
	private ATM atm;
	
/*	public static void main(String[] args) {
		AtmRegister atmRegister = new AtmRegister();
		atmRegister.setVisible(true);
	}
*/	
	public AtmRegister(ATM atm) {
		setTitle("ATM Machine - ECE 373 Project");
		setSize(430,500);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		this.atm = atm;
		initializeComponents();
		setVisible(true);
	}
	
	private void initializeComponents() {
		contentPane = new JPanel();
		contentPane.setLayout(new FlowLayout(0, 50, 10));
		setContentPane(contentPane);
		
		JLabel lblQuestions = new JLabel("Please fill in the following fields:");
		contentPane.add(lblQuestions);
		
		JPanel panelFields = new JPanel();
		panelFields.setLayout(new GridLayout(7, 2));
		
		JLabel lblName = new JLabel("Name: ");
		JLabel lblUsername = new JLabel("Username: ");
		JLabel lblPassword = new JLabel("Password: ");
		JLabel lblAddress = new JLabel("Address: ");
		JLabel lblPhone = new JLabel("Phone Number: ");
		JLabel lblAge = new JLabel("Age: ");
		JLabel lblBirthday = new JLabel("Birthday: ");
		
		JTextField txtName = new JTextField();
		JTextField txtUsername = new JTextField();
		JTextField txtPassword = new JTextField();
		JTextField txtAddress = new JTextField();
		JTextField txtPhone = new JTextField();
		JTextField txtAge = new JTextField();
		JTextField txtBirthday = new JTextField();
		
		panelFields.add(lblName);
		panelFields.add(txtName);

		panelFields.add(lblUsername);
		panelFields.add(txtUsername);
		
		panelFields.add(lblPassword);
		panelFields.add(txtPassword);
		
		panelFields.add(lblAddress);
		panelFields.add(txtAddress);

		panelFields.add(lblPhone);
		panelFields.add(txtPhone);

		panelFields.add(lblAge);
		panelFields.add(txtAge);

		panelFields.add(lblBirthday);
		panelFields.add(txtBirthday);
		
		contentPane.add(panelFields);
		
		JButton btnSubmit = new JButton("Submit");
		contentPane.add(btnSubmit);
		
		imageIcon = new ImageIcon("photo.jpg");
		JLabel photo = new JLabel(imageIcon);
		
		contentPane.add(photo);
		
		//JLabel lblAccountId = new JLabel("Your assigned account ID is: ");
		//contentPane.add(lblAccountId);
	
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				User newUser = new User();
				
				String userName = txtName.getText();
				String userUsername = txtUsername.getText();
				String userPassword =  txtPassword.getText();
				String userAddress = txtAddress.getText();
				String userPhone =  txtPhone.getText();
				String userAge =  txtAge.getText();
				int userAgeInt = Integer.parseInt(userAge);
				String userBirthday =  txtBirthday.getText();
				
				newUser.setName(userName);
				newUser.setUsername(userUsername);
				newUser.setPassword(userPassword);
				newUser.setAddress(userAddress);
				newUser.setPhone(userPhone);
				newUser.setAge(userAgeInt);
				newUser.setBirthday(userBirthday);
				
				atm.getUserList().add(newUser);
				AtmLogin atml = new AtmLogin(atm);
				
				setVisible(false);
				
			}
			
			
			
		});
		
	
	
	}
	
	public ATM getATM() {
		return atm;
	}
	
}
	
