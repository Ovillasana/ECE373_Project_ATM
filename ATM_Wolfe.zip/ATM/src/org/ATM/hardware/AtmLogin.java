package org.ATM.hardware;

import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

public class AtmLogin extends JFrame {

	private static final long serialVersionUID = -5535484166491623591L;
	private JPanel contentPane;
	private JPanel loginPanel;
	private ATM atm;

	public AtmLogin(ATM atm) {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(440, 200);
		setTitle("ATM Machine - ECE 373 Project");
		setLocationRelativeTo(null);
		this.atm = atm;
		initializeComponents();
		setVisible(true);
	}
	
	private void initializeComponents() {
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new GridLayout(2, 1));
		
		JPanel panelContent = new JPanel();
		panelContent.setLayout(new FlowLayout());
		
		setContentPane(contentPane);
		
		loginPanel = new JPanel();
		loginPanel.setLayout(new GridLayout(2, 2));
		
		JLabel lblUsername = new JLabel("Username:");
		JLabel lblPassword = new JLabel("Password:");
		
		JTextField txtUsername = new JTextField("", 10);			
		JPasswordField txtPass = new JPasswordField("", 10);
		
		loginPanel.add(lblUsername);
		loginPanel.add(txtUsername);
		
		loginPanel.add(lblPassword);
		loginPanel.add(txtPass);
		
		JButton btnLogin = new JButton("Login");
		panelContent.add(loginPanel);
		panelContent.add(btnLogin);
		contentPane.add(panelContent);
		
		JPanel panelRegister = new JPanel();
		JLabel lblRegister = new JLabel("Don't have an account?");
		JButton btnRegister = new JButton("Register");
		
		panelRegister.add(lblRegister);
		panelRegister.add(btnRegister);
		
		contentPane.add(panelRegister);
		
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				boolean foundUsername = false;
				boolean foundPassword= false;
				int index = 0;
				String userUsername = txtUsername.getText();
				String userPass = new String(txtPass.getPassword());
								
				for (int i = 0; i<atm.getUserList().size(); i++ ) {
					
					if (atm.getUserList().get(i).getUsername().equals(userUsername)) {
						foundUsername = true;
						index  = i;
						if (atm.getUserList().get(i).getPassword().equals(userPass)) {
						 foundPassword = true;
						}
						else {
							foundPassword = false;
						}
					}
				}
				
				if( foundUsername == true ) {
					if (foundPassword == true) {
						AtmGui atmgui = new AtmGui(atm.getUserList().get(index));
					}
					else {
						JOptionPane.showConfirmDialog(null, "Incorrect Passsword, please try again",
			        			"Error", 
			        		    JOptionPane.OK_CANCEL_OPTION, 
			        		    JOptionPane.PLAIN_MESSAGE);
					}
				}
				
				else if (foundUsername == false) {
					JOptionPane.showConfirmDialog(null, "Incorrect Username, please try again",
		        			"Error", 
		        		    JOptionPane.OK_CANCEL_OPTION, 
		        		    JOptionPane.PLAIN_MESSAGE);
				}
				
			}
			
		});
		
	btnRegister.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			AtmRegister atmreg = new AtmRegister(atm);
			
		}
	});
	}

}
