package org.ATM.hardware;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import java.io.Serializable;
import java.util.ArrayList;


import org.ATM.people.User;

public class ATM implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public final ArrayList<User> userList = new ArrayList<User>();
	public double moneyAvailable;
	public double moneyWithdrawn;
	
	public ATM() {
		this.moneyAvailable = 0.00;
		this.moneyWithdrawn = 0.00;
		
	}

	public double getMoneyAvailable() {
		return moneyAvailable;
	}

	public void setMoneyAvailable(double moneyAvailable) {
		this.moneyAvailable = moneyAvailable;
	}

	public double getMoneyWithdrawn() {
		return moneyWithdrawn;
	}

	public void setMoneyWithdrawn(double moneyWithdrawn) {
		this.moneyWithdrawn = moneyWithdrawn;
	}

	public ArrayList<User> getUserList() {
		return userList;
	}
	
	public void createAccount(User u1) {
		
		
	}
	
	
	public static void saveData(ATM atm) {
		FileOutputStream outFile = null;
		ObjectOutputStream objOut = null;
		
		try {
			outFile = new FileOutputStream("atm.ser");
			objOut = new ObjectOutputStream(outFile);
			objOut.writeObject((atm));
			objOut.close();
			outFile.close();	
		}
		
		catch (IOException i) {
			i.printStackTrace();
		}
		
	}
	
	public static ATM loadData() {
		
		FileInputStream inFile = null;
		ObjectInputStream objIn = null;
		ATM atm = null;
		
		try {
			inFile = new FileInputStream("university.ser");
			objIn= new ObjectInputStream(inFile);
			atm = (ATM) objIn.readObject();
			objIn.close();
			inFile.close();
		}	
		
		catch(IOException i) {
			i.printStackTrace();
		}
		
		catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
		return atm;
		
	}
	
}
