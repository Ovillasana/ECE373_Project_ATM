package org.ATM.hardware;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.ATM.people.User;

public class AtmRegister extends JFrame {

	private static final long serialVersionUID = -5323104247007829603L;
	private JPanel contentPane;
	private ImageIcon imageIcon;
	private ATM atm;
	
/*	public static void main(String[] args) {
		AtmRegister atmRegister = new AtmRegister();
		atmRegister.setVisible(true);
	}
*/	
	public AtmRegister(ATM atm) {
		setTitle("ATM Machine - ECE 373 Project");
		setSize(430,500);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setResizable(false);
		this.atm = atm;
		initializeComponents();
		getContentPane().setBackground(Color.cyan);
		setVisible(true);
	}
	
	private void initializeComponents() {
		contentPane = new JPanel();
		contentPane.setLayout(new FlowLayout(0, 50, 10));
		setContentPane(contentPane);
		
		JLabel lblQuestions = new JLabel("Please fill in the following fields:");
		contentPane.add(lblQuestions);
		
		JPanel panelFields = new JPanel();
		panelFields.setLayout(new GridLayout(10, 2));
		
		JLabel lblName = new JLabel("Name: ");
		lblName.setBackground(Color.cyan);
		
		JLabel lblUsername = new JLabel("Username: ");
		JLabel lblPassword = new JLabel("Password: ");
		JLabel lblAddress = new JLabel("Street Address: ");
		JLabel lblCity = new JLabel ("City: ");
		JLabel lblState = new JLabel ("State: ");
		JLabel lblZip = new JLabel ("Zip: ");
		JLabel lblPhone = new JLabel("Phone Number: ");
		JLabel lblAge = new JLabel("Age: ");
		JLabel lblBirthday = new JLabel("Birthday: ");
		
		JTextField txtName = new JTextField();
		JTextField txtUsername = new JTextField();
		JTextField txtPassword = new JTextField();
		JTextField txtAddress = new JTextField();
		JTextField txtCity = new JTextField();
		JTextField txtState = new JTextField();
		JTextField txtZip = new JTextField();
		JTextField txtPhone = new JTextField();
		JTextField txtAge = new JTextField();
		JTextField txtBirthday = new JTextField();
		
		panelFields.add(lblName);
		panelFields.add(txtName);

		panelFields.add(lblUsername);
		panelFields.add(txtUsername);
		
		panelFields.add(lblPassword);
		panelFields.add(txtPassword);
		
		panelFields.add(lblAddress);
		panelFields.add(txtAddress);
		
		panelFields.add(lblState);
		panelFields.add(txtState);
		
		panelFields.add(lblCity);
		panelFields.add(txtCity);
		
		panelFields.add(lblZip);
		panelFields.add(txtZip);

		panelFields.add(lblPhone);
		panelFields.add(txtPhone);
		
		panelFields.add(lblAge);
		panelFields.add(txtAge);

		panelFields.add(lblBirthday);
		panelFields.add(txtBirthday);
		
		contentPane.add(panelFields);
		
		JButton btnSubmit = new JButton("Submit");
		contentPane.add(btnSubmit);
		
		imageIcon = new ImageIcon("photo.jpg");
		JLabel photo = new JLabel(imageIcon);
		
		contentPane.add(photo);
		
		//JLabel lblAccountId = new JLabel("Your assigned account ID is: ");
		//contentPane.add(lblAccountId);
	
		btnSubmit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				User newUser = new User();
				
				String userName = txtName.getText();
				String userUsername = txtUsername.getText();
				String userPassword =  txtPassword.getText();
				String userAddress = txtAddress.getText();
				String userAdress2 = (txtCity.getText() + ", "+ txtState.getText() + " " + txtZip.getText());
				String userPhone =  txtPhone.getText();
				String userAge =  txtAge.getText();
				int userAgeInt = Integer.parseInt(userAge);
				String userBirthday =  txtBirthday.getText();
				
				boolean usernameHazard = false;
				for (int i = 0; i<atm.getUserList().size(); i++) {
					
					if (atm.getUserList().get(i).getUsername().equals(userUsername)) {
						usernameHazard = true;
					    
					}
				}
				
				if (usernameHazard == false) {
				newUser.setName(userName);
				newUser.setUsername(userUsername);
				newUser.setPassword(userPassword);
				newUser.setAddress(userAddress);
				newUser.setAddress2(userAdress2);
				newUser.setPhone(userPhone);
				newUser.setAge(userAgeInt);
				newUser.setBirthday(userBirthday);
				
				Random rand = new Random();
				int value = rand.nextInt(99999);
				newUser.setUserID(value);
				
				atm.getUserList().add(newUser);
				
				JOptionPane.showMessageDialog(null, "Your account has been created! Your UserID is: " +
				newUser.getUserID()+ " You may now login",
						"Welcome", JOptionPane.OK_OPTION);
				AtmLogin atml = new AtmLogin(atm);
				setVisible(false);
				
			}
				
				else {
				
					JOptionPane.showMessageDialog(null, "The username " + userUsername + " is taken. Please try another username.",
		        			"Error", 
		        		    JOptionPane.CANCEL_OPTION);
				}
			}
			
			
			
		});
		
	
	
	}
	
	public ATM getATM() {
		return atm;
	}
	
}
	
