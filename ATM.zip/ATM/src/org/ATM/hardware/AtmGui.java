package org.ATM.hardware;

import java.awt.BorderLayout;
import java.awt.CheckboxGroup;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.PrintStream;
import java.text.DecimalFormat;
import java.util.concurrent.TimeUnit;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;

import org.ATM.people.User;

public class AtmGui extends JFrame {

	private static final long serialVersionUID = 8980271630829931165L;
	private JPanel contentPane;
	private User user;
	private int accountID = 0;
	private String accountType = "unknown";
	private JTextArea textArea;
	private PrintStream standardOut;
	private ImageIcon imageIcon;
	private JPanel panelRight;
	private JPanel panelLeft;
	private JPanel panelMain;
	private ATM atm;
	/////////////////
	//For keypad implementation
	String numberString = ""; 

	JButton b1 = new JButton("1");
	JButton b2 = new JButton("2");
	JButton b3 = new JButton("3");
	JButton b4 = new JButton("4");
	JButton b5 = new JButton("5");
	JButton b6 = new JButton("6");
	JButton b7 = new JButton("7");
	JButton b8 = new JButton("8");
	JButton b9 = new JButton("9");
	JButton b0 = new JButton("0");
	/////////////////


	public AtmGui(User user, ATM atm) {

		this.user = user;
		this.atm = atm;
		setTitle("ATM Machine - ECE 373 Project");
		setSize(848,375);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);

		contentPane = new JPanel();
		// Adding an empty border for more beauty :-)
		contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
		
		// Setting the Layout to Borderlayout for dividing the Layout into 3 parts (top [JLabel], middle[Content], bottom[JLabel])
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);

		initializeComponents();
		setVisible(true);
	}
	
	private void initializeMainComponents() {
		panelMain = new JPanel();
		// 1 row, 2 columns
		panelMain.setLayout(new GridLayout(1, 2, 0, 0));
		contentPane.add(panelMain);
		
		panelLeft = new JPanel();
		// 2 rows, 1 column, gap of 10,10
		panelLeft.setLayout(new GridLayout(2, 1, 10, 10));
		panelMain.add(panelLeft);
		
		panelRight = new JPanel();
		panelRight.setLayout(new FlowLayout());
		panelMain.add(panelRight);
		
		JLabel lblWelcome = new JLabel("Welcome " +  user.getName() + "!");
		contentPane.add(lblWelcome, BorderLayout.NORTH);
		

		JLabel lblAccountType = new JLabel("No Account Selected");
		lblAccountType.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(lblAccountType, BorderLayout.SOUTH);
		
		Timer timer = new Timer(500, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(accountID != 0) {
				lblAccountType.setText("Account Number: " + accountID);
				}
			}
		});
		
		timer.start();
		
	}
	
	private void initializeComponents() {
		initializeMainComponents();
		addWithdrawPanel();
		addAccountsPanel();
		addUserDetailsPanel();
		getContentPane().setBackground(Color.cyan);
	}
	
	private void addUserDetailsPanel() {
		JPanel panelUserDetails = new JPanel();
		// 2 rows, 1 column, vgap of 30 
		panelUserDetails.setLayout(new GridLayout(2, 1, 0, 30));
		panelRight.add(panelUserDetails);

		JPanel panelAddress = new JPanel();
		// 3 rows, 1 column, hgap of 5
		panelAddress.setLayout(new GridLayout(3, 1, 5, 0));
		panelUserDetails.add(panelAddress);

		JLabel lblName = new JLabel(user.getName());
		lblName.setHorizontalAlignment(SwingConstants.LEFT);
		
		JLabel lblAddress = new JLabel(user.getAddress());
		lblAddress.setHorizontalAlignment(SwingConstants.LEFT);

		JLabel lblState = new JLabel(user.getAddress2());
		lblState.setHorizontalAlignment(SwingConstants.LEFT);
		
		panelAddress.add(lblName);
		panelAddress.add(lblAddress);
		panelAddress.add(lblState);
		
		JPanel panelPrivateDetails = new JPanel();
		panelPrivateDetails.setLayout(new GridLayout(5, 1, 0, 0));
		panelUserDetails.add(panelPrivateDetails);
		
		JLabel lblAge = new JLabel("Age: "+ user.getAge());
		JLabel lblBirthday = new JLabel("Birthday: " + user.getBirthday());
		JLabel lblUserId = new JLabel("User ID: "+ user.getUserID());
		panelPrivateDetails.add(lblAge);
		panelPrivateDetails.add(lblBirthday);
		panelPrivateDetails.add(lblUserId);
		
		// Adding the avatar logo to the JLabel
		imageIcon = new ImageIcon("photo.jpg");
		JLabel lblAvatar = new JLabel(imageIcon);
		panelRight.add(lblAvatar);
		getContentPane().setBackground(Color.cyan);
		
		JButton logoutButton = new JButton("Log Out");
		
		panelPrivateDetails.add(logoutButton);
		
		logoutButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				user.getCheckingAccount().setPinBoolean(false);
				user.getSavingAccount().setPinBoolean(false);
				AtmLogin logIn = new AtmLogin(atm);
				setVisible(false);
			}
		});
		

	}
		
	
	private void addAccountsPanel() {
		DecimalFormat df = new DecimalFormat();
		df.setMaximumFractionDigits(2);
		textArea = new JTextArea();

		
		JPanel panelAccounts = new JPanel();
		panelLeft.add(panelAccounts);
		panelAccounts.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		
		JLabel lblSelectAccount = new JLabel("Select Account:");
		panelAccounts.add(lblSelectAccount);
		
		JScrollPane scrollPaneCheckboxes = new JScrollPane();
		scrollPaneCheckboxes.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		panelAccounts.add(scrollPaneCheckboxes);
		
		JPanel panelCheckboxes = new JPanel();
		scrollPaneCheckboxes.setViewportView(panelCheckboxes);
		panelCheckboxes.setLayout(new GridLayout(3, 1, 0, 0));

		                                     
		JCheckBox chckbxSavingAccount = new JCheckBox("Saving Account - Balance: $" + df.format(user.getSavingAccount().getBalance()));
		chckbxSavingAccount.setHorizontalAlignment(SwingConstants.LEFT);
		
		JCheckBox chckbxCheckingAccount = new JCheckBox("Checking Account - Balance: $" + df.format(user.getCheckingAccount().getBalance()));
		chckbxCheckingAccount.setHorizontalAlignment(SwingConstants.LEFT);
		
		
		
		ButtonGroup group = new ButtonGroup();
		group.add(chckbxSavingAccount);
		group.add(chckbxCheckingAccount);
		
		
		panelCheckboxes.add(chckbxSavingAccount);
		panelCheckboxes.add(chckbxCheckingAccount);
		
		Timer timer = new Timer(500, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				chckbxSavingAccount.setText("Saving Account - Balance: $" + df.format(user.getSavingAccount().getBalance()));
				chckbxCheckingAccount.setText("Checking Account - Balance: $" + df.format(user.getCheckingAccount().getBalance()));
			}
		});
		
		timer.start();
		chckbxSavingAccount.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (chckbxSavingAccount.isSelected()) {
					accountID = user.getCheckingAccount().getAccountNumber();
					accountType = "Savings";
				}
			}
		});
		
		chckbxCheckingAccount.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if(chckbxCheckingAccount.isSelected()) {
					accountID = user.getSavingAccount().getAccountNumber();
					accountType = "Checkings";
				}
			}
		});

	}

	private void addWithdrawPanel() {
		
		
		DecimalFormat df = new DecimalFormat();
		df.setMaximumFractionDigits(2);
		JPanel panelWithdrawOuter = new JPanel();
		panelLeft.add(panelWithdrawOuter);
		JLabel lblAmount = new JLabel("Make Transaction:");
		panelWithdrawOuter.add(lblAmount);
		panelWithdrawOuter.setLayout(new FlowLayout(FlowLayout.LEFT, 6, 50));

		JPanel panelWithdrawInner = new JPanel();
		panelWithdrawOuter.add(panelWithdrawInner);
		panelWithdrawInner.setLayout(new GridLayout(2, 2, 30, 15));
		
		//JTextField txtDeposit = new JTextField();
		//panelWithdrawInner.add(txtDeposit);
		
		JButton btnDeposit = new JButton("Deposit");
		panelWithdrawInner.add(btnDeposit);
		
		//JTextField txtWithdraw = new JTextField();
		//panelWithdrawInner.add(txtWithdraw);
		JButton btnSetPin = new JButton("Set PIN");
		panelWithdrawInner.add(btnSetPin);
		
		JButton btnWithdraw = new JButton("Withdraw");
		panelWithdrawInner.add(btnWithdraw);
		
		JLabel lblWallet = new JLabel("User Wallet: $" + df.format(user.getWallet()));
		panelWithdrawInner.add(lblWallet);
		
		Timer timer = new Timer(500, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				if(accountID != 0) {
				lblWallet.setText("User Wallet: $" + df.format(user.getWallet()));
				}
			}
		});
		
		timer.start();
		
		btnSetPin.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				int pin = 0;
				numberString = "";

				textArea = new JTextArea();
				textArea.setEditable(false);
				PrintStream printStream = new PrintStream (new TextOutputStream(textArea));
				standardOut = System.out;
				System.setOut(printStream);
				System.setErr(printStream);
				
				 JPanel pinPanel = new JPanel(new GridLayout(4, 3));
				 pinPanel.add(b1);
				 pinPanel.add(b2);
				 pinPanel.add(b3);
				 pinPanel.add(b4);
				 pinPanel.add(b5);
				 pinPanel.add(b6);
				 pinPanel.add(b7);
				 pinPanel.add(b8);
				 pinPanel.add(b9);
				 pinPanel.add(b0);

				    ButtonListener listener = new ButtonListener();

				 if(b1.getActionListeners().length < 1){
				    b1.addActionListener(listener);
				    b2.addActionListener(listener);
				    b3.addActionListener(listener);
				    b4.addActionListener(listener);
				    b5.addActionListener(listener);
				    b6.addActionListener(listener);
				    b7.addActionListener(listener);
				    b8.addActionListener(listener);
				    b9.addActionListener(listener);
				    b0.addActionListener(listener);
			}
				   // setLayout(new BorderLayout());
				    //add(pinPanel, BorderLayout.CENTER);
				   // add(bclear, BorderLayout.SOUTH);
				    //add(jtf, BorderLayout.NORTH);

				   // jtf.setHorizontalAlignment(SwingConstants.RIGHT);
				   // jtf.setPreferredSize(new Dimension(300, 30));
				    
				    if(accountType.equals("Savings")){
						if(!user.getSavingAccount().getPinBoolean()) {
					int result1 = JOptionPane.showConfirmDialog(null, pinPanel, "Enter current PIN to continue.  Default value is 0", JOptionPane.OK_CANCEL_OPTION);
					
					if(result1 == JOptionPane.OK_OPTION) {
						pin = Integer.parseInt(numberString);
						
							if(user.getSavingAccount().requestPin(pin)) {
								user.getSavingAccount().setFailCounter(0);
								user.getSavingAccount().setPinBoolean(false);;
							}
							else if(user.getSavingAccount().getFailCounter() > 3){
								textArea.setSize(480, 480);
								textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
						
								JOptionPane.showMessageDialog(null, textArea, "Error", JOptionPane.PLAIN_MESSAGE);
								JOptionPane.showMessageDialog(null, "Incorrect PIN, you exceeded the number of failed attempts. You account has been locked.",
					        			"Error", 
					        		    JOptionPane.CANCEL_OPTION);
								System.exit(0);
							}else {
								textArea.setSize(480, 480);
								textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
						
								JOptionPane.showMessageDialog(null, textArea, "Error", JOptionPane.PLAIN_MESSAGE);
								return;
							}

					}else {
						return;
					}
						}
					}
					else if(accountType.equals("Checkings")) {
						if(!user.getCheckingAccount().getPinBoolean()) {
							int result1 = JOptionPane.showConfirmDialog(null, pinPanel, "Enter current PIN to continue.  Default value is 0", JOptionPane.OK_CANCEL_OPTION);
							
							if(result1 == JOptionPane.OK_OPTION) {
								pin = Integer.parseInt(numberString);

									if(user.getCheckingAccount().requestPin(pin)) {
										user.getCheckingAccount().setFailCounter(0);
										user.getCheckingAccount().setPinBoolean(false);
									}
									else if(user.getCheckingAccount().getFailCounter() > 3){
										
										textArea.setSize(480, 480);
										textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
									
										JOptionPane.showMessageDialog(null, textArea, "Error", JOptionPane.PLAIN_MESSAGE);
										System.exit(0);
									}else {
										
										textArea.setSize(480, 480);
										textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
									
										JOptionPane.showMessageDialog(null, textArea, "Error", JOptionPane.PLAIN_MESSAGE);
										return;
									}
							}else {
								return;
							}
								
							}
					}else {
						System.out.println("Error: no account selected.");
						textArea.setSize(480, 480);
						textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
						
						
						JOptionPane.showMessageDialog(null, textArea, "Deposit Complete", JOptionPane.PLAIN_MESSAGE);
						return;
					}
				    
				    numberString = "";
				    int result = JOptionPane.showConfirmDialog(null, pinPanel, "Enter new PIN number", JOptionPane.OK_CANCEL_OPTION);
					
					if(result == JOptionPane.OK_OPTION) {
						if(accountType.equals("Savings")) {
							user.getSavingAccount().createPIN(numberString);
							textArea.setSize(480, 480);
							textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
						
							JOptionPane.showMessageDialog(null, textArea, "Set PIN", JOptionPane.PLAIN_MESSAGE);
						}else if (accountType.equals("Checkings")) {
							user.getCheckingAccount().createPIN(numberString);
							textArea.setSize(480, 480);
							textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
						
							JOptionPane.showMessageDialog(null, textArea, "Set PIN", JOptionPane.PLAIN_MESSAGE);
						}
					}
			
			}
			
		});
		//handles deposits
		btnDeposit.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {

					double depositAmount = 0;
					int pin = 0;
					numberString = "";
					JTextField depositField = new JTextField(10);
					textArea = new JTextArea();
					textArea.setEditable(false);
					PrintStream printStream = new PrintStream (new TextOutputStream(textArea));
					standardOut = System.out;
					System.setOut(printStream);
					System.setErr(printStream);
					JPanel frame = new JPanel();
					frame.add(depositField);
					frame.setLayout(new BoxLayout(frame, BoxLayout.Y_AXIS));
					///////////////////////////////////////////////////////////
  
					 JPanel pinPanel = new JPanel(new GridLayout(4, 3));
					 pinPanel.add(b1);
					 pinPanel.add(b2);
					 pinPanel.add(b3);
					 pinPanel.add(b4);
					 pinPanel.add(b5);
					 pinPanel.add(b6);
					 pinPanel.add(b7);
					 pinPanel.add(b8);
					 pinPanel.add(b9);
					 pinPanel.add(b0);

					    ButtonListener listener = new ButtonListener();

					 if(b1.getActionListeners().length < 1){
					    b1.addActionListener(listener);
					    b2.addActionListener(listener);
					    b3.addActionListener(listener);
					    b4.addActionListener(listener);
					    b5.addActionListener(listener);
					    b6.addActionListener(listener);
					    b7.addActionListener(listener);
					    b8.addActionListener(listener);
					    b9.addActionListener(listener);
					    b0.addActionListener(listener);
				}
					  //  setLayout(new BorderLayout());
					  //  add(pinPanel, BorderLayout.CENTER);
					 //   add(bclear, BorderLayout.SOUTH);
					 //   add(jtf, BorderLayout.NORTH);

					 //   jtf.setHorizontalAlignment(SwingConstants.RIGHT);
					 //   jtf.setPreferredSize(new Dimension(300, 30));
					

					if(accountType.equals("Savings")){
						if(!user.getSavingAccount().getPinBoolean()) {
					int result1 = JOptionPane.showConfirmDialog(null, pinPanel, "Enter four digit PIN number", JOptionPane.OK_CANCEL_OPTION);
					
					if(result1 == JOptionPane.OK_OPTION) {
						pin = Integer.parseInt(numberString);
						
							if(user.getSavingAccount().requestPin(pin)) {
								user.getSavingAccount().setFailCounter(0);
							}
							else if(user.getSavingAccount().getFailCounter() > 3){
								textArea.setSize(480, 480);
								textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
						
								JOptionPane.showMessageDialog(null, textArea, "Error", JOptionPane.PLAIN_MESSAGE);
								JOptionPane.showMessageDialog(null, "Incorrect PIN, you exceeded the number of failed attempts. You account has been locked.",
					        			"Error", 
					        		    JOptionPane.CANCEL_OPTION);
								System.exit(0);
							}else {
								textArea.setSize(480, 480);
								textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
						
								JOptionPane.showMessageDialog(null, textArea, "Error", JOptionPane.PLAIN_MESSAGE);
								return;
							}

					}else {
						return;
					}
						}
					}
					else if(accountType.equals("Checkings")) {
						if(!user.getCheckingAccount().getPinBoolean()) {
							int result1 = JOptionPane.showConfirmDialog(null, pinPanel, "Enter four digit PIN number", JOptionPane.OK_CANCEL_OPTION);
							
							if(result1 == JOptionPane.OK_OPTION) {
								pin = Integer.parseInt(numberString);

									if(user.getCheckingAccount().requestPin(pin)) {
										user.getCheckingAccount().setFailCounter(0);
									}
									else if(user.getCheckingAccount().getFailCounter() > 3){
										
										textArea.setSize(480, 480);
										textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
									
										JOptionPane.showMessageDialog(null, textArea, "Error", JOptionPane.PLAIN_MESSAGE);
										System.exit(0);
									}else {
										
										textArea.setSize(480, 480);
										textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
									
										JOptionPane.showMessageDialog(null, textArea, "Error", JOptionPane.PLAIN_MESSAGE);
										return;
									}
							}else {
								return;
							}
								
							}
					}else {
						System.out.println("Error: no account selected.");
						textArea.setSize(480, 480);
						textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
						
						
						JOptionPane.showMessageDialog(null, textArea, "Deposit Complete", JOptionPane.PLAIN_MESSAGE);
						return;
					}

					int result = JOptionPane.showConfirmDialog(null, frame, "Deposit", JOptionPane.OK_CANCEL_OPTION);
					
					if(result == JOptionPane.OK_OPTION) {				
						while(true) {
							try {
						depositAmount = Double.parseDouble(depositField.getText());
						break;
							}catch(NumberFormatException ignore) {
								JOptionPane.showMessageDialog(null,  "Invalid input.");
								break;
							}
						}
					if(depositAmount != 0) {
						if(accountType.equals("Savings")) {
						 user.setWallet(user.getSavingAccount().depositMoney(depositAmount, user.getWallet()));
						}
						else if(accountType.equals("Checkings")) {
							user.setWallet(user.getCheckingAccount().depositMoney(depositAmount, user.getWallet()));
							
						}
						else {
							System.out.println("Error: no account selected.");
						}
						
						
						textArea.setSize(480, 480);
						textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
						
						
						JOptionPane.showMessageDialog(null, textArea, "Deposit Complete", JOptionPane.PLAIN_MESSAGE);
					}
					}
					return;

				}
			
		});
		
		btnWithdraw.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {

					double withdrawAmount = 0;
					int pin = 0;
					numberString = "";
					JTextField withdrawField = new JTextField(10);
					textArea = new JTextArea();
					textArea.setEditable(false);
					PrintStream printStream = new PrintStream (new TextOutputStream(textArea));
					standardOut = System.out;
					System.setOut(printStream);
					System.setErr(printStream);
					JPanel frame = new JPanel();
					frame.add(withdrawField);
					frame.setLayout(new BoxLayout(frame, BoxLayout.Y_AXIS));
					///////////////////////////////////////////////////////////
  
					 JPanel pinPanel = new JPanel(new GridLayout(4, 3));
					 pinPanel.add(b1);
					 pinPanel.add(b2);
					 pinPanel.add(b3);
					 pinPanel.add(b4);
					 pinPanel.add(b5);
					 pinPanel.add(b6);
					 pinPanel.add(b7);
					 pinPanel.add(b8);
					 pinPanel.add(b9);
					 pinPanel.add(b0);

					    ButtonListener listener = new ButtonListener();

					 if(b1.getActionListeners().length < 1){
					    b1.addActionListener(listener);
					    b2.addActionListener(listener);
					    b3.addActionListener(listener);
					    b4.addActionListener(listener);
					    b5.addActionListener(listener);
					    b6.addActionListener(listener);
					    b7.addActionListener(listener);
					    b8.addActionListener(listener);
					    b9.addActionListener(listener);
					    b0.addActionListener(listener);
				}
					 //   setLayout(new BorderLayout());
					   // add(pinPanel, BorderLayout.CENTER);
					   // add(bclear, BorderLayout.SOUTH);
					 //   add(jtf, BorderLayout.NORTH);

					  //  jtf.setHorizontalAlignment(SwingConstants.RIGHT);
					  //  jtf.setPreferredSize(new Dimension(300, 30));
					

					if(accountType.equals("Savings")){
						if(!user.getSavingAccount().getPinBoolean()) {
					int result1 = JOptionPane.showConfirmDialog(null, pinPanel, "Enter four digit PIN number", JOptionPane.OK_CANCEL_OPTION);
					
					if(result1 == JOptionPane.OK_OPTION) {
						pin = Integer.parseInt(numberString);
						
							if(user.getSavingAccount().requestPin(pin)) {
								user.getSavingAccount().setFailCounter(0);
							}
							else if(user.getSavingAccount().getFailCounter() > 3){
								textArea.setSize(480, 480);
								textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
						
								JOptionPane.showMessageDialog(null, textArea, "Error", JOptionPane.PLAIN_MESSAGE);
								System.exit(0);
							}else {
								textArea.setSize(480, 480);
								textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
						
								JOptionPane.showMessageDialog(null, textArea, "Error", JOptionPane.PLAIN_MESSAGE);
								return;
							}

					}else {
						return;
					}
						}
					}
					else if(accountType.equals("Checkings")) {
						if(!user.getCheckingAccount().getPinBoolean()) {
							int result1 = JOptionPane.showConfirmDialog(null, pinPanel, "Enter four digit PIN number", JOptionPane.OK_CANCEL_OPTION);
							
							if(result1 == JOptionPane.OK_OPTION) {
								pin = Integer.parseInt(numberString);

									if(user.getCheckingAccount().requestPin(pin)) {
										user.getCheckingAccount().setFailCounter(0);
									}
									else if(user.getCheckingAccount().getFailCounter() > 3){
										
										textArea.setSize(480, 480);
										textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
									
										JOptionPane.showMessageDialog(null, textArea, "Error", JOptionPane.PLAIN_MESSAGE);
										System.exit(0);
									}else {
										
										textArea.setSize(480, 480);
										textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
									
										JOptionPane.showMessageDialog(null, textArea, "Error", JOptionPane.PLAIN_MESSAGE);
										return;
									}
							}else {
								return;
							}
								
							}
					}else {
						System.out.println("Error: no account selected.");
						textArea.setSize(480, 480);
						textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
						
						
						JOptionPane.showMessageDialog(null, textArea, "Withdrawal Complete", JOptionPane.PLAIN_MESSAGE);
						return;
					}

					int result = JOptionPane.showConfirmDialog(null, frame, "Withdraw", JOptionPane.OK_CANCEL_OPTION);
					
					if(result == JOptionPane.OK_OPTION) {				
						while(true) {
							try {
								withdrawAmount = Double.parseDouble(withdrawField.getText());
						break;
							}catch(NumberFormatException ignore) {
								JOptionPane.showMessageDialog(null,  "Invalid input.");
								break;
							}
						}
					if(withdrawAmount != 0) {
						if(accountType.equals("Savings")) {
						 user.setWallet(user.getSavingAccount().withdrawMoney(withdrawAmount,user.getWallet()));
						}
						else if(accountType.equals("Checkings")) {
							user.setWallet(user.getCheckingAccount().withdrawMoney(withdrawAmount, user.getWallet()));
							
						}
						else {
							System.out.println("Error: no account selected.");
						}
						textArea.setSize(480, 480);
						textArea.setPreferredSize(new Dimension(800, textArea.getPreferredSize().height));
						
						
						JOptionPane.showMessageDialog(null, textArea, "Withdrawal Complete", JOptionPane.PLAIN_MESSAGE);
					}
					}
					return;

				}

	
		});
	}
	class ButtonListener implements ActionListener {

	    @Override
	    public void actionPerformed(ActionEvent e) {
	        if (e.getSource() == b1) {
	            numberString += "1";
	        } else if (e.getSource() == b2) {
	            numberString += "2";
	        }else if (e.getSource() == b3) {
	        	numberString +="3";
	        }else if (e.getSource() == b4) {
	            numberString += "4";
	        }else if (e.getSource() == b5) {
	        	numberString +="5";
	        }else if (e.getSource() == b6) {
	            numberString += "6";
	        }else if (e.getSource() == b7) {
	        	numberString +="7";
	        }else if (e.getSource() == b8) {
	            numberString += "8";
	        }else if (e.getSource() == b9) {
	        	numberString +="9";
	        }else if (e.getSource() == b0) {
	        	numberString +="0";
	        }

	        
	    }
	}
}



