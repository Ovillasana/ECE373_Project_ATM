package org.ATM.hardware;

import java.sql.Savepoint;

import org.ATM.*;
import org.ATM.people.User;
import org.ATM.software.Account;
import org.ATM.software.Checking;
import org.ATM.software.Saving;
public class Driver1 {
    
	public static void main(String[] args) {

		ATM atm = new ATM();
		
		// initialization of users//
		User u1 = new User();
		u1.setName("Michael Scott");
		u1.setAge(53);
		u1.setBirthday("03/15/1964");
		u1.setAddress("1725 Slough Avenue");
		u1.setAddress2("Scranton, PA 18540");
		u1.setVIP(true);
		u1.setUsername("MichaelScarn");
		u1.setPassword("123456789");
		u1.setPhone("(800)964-DMPC");
		u1.setUserID(12345);
		
		User u2 = new User();
		u2.setName("Dwight Schrute");
		u2.setAge(40);
		u2.setBirthday("01/20/1977");
		u2.setAddress("1725 Slough Avenue");
		u2.setAddress2("Scranton, PA 18540");
		u2.setVIP(true);
		u2.setUsername("KurtIII");
		u2.setPassword("123456789");
		u2.setPhone("(800)964-DMPC");
		u2.setUserID(12345);

		
		User u3 = new User();
		u3.setName("Jim Halpert");
		u3.setAge(39);
		u3.setBirthday("10/01/1978");
		u3.setAddress("1725 Slough Avenue");
		u3.setAddress2("Scranton, PA 18540");
		u3.setVIP(true);
		u3.setUsername("Tuna");
		u3.setPassword("123");
		u3.setPhone("(800)964-DMPC");
		u3.setUserID(12345);

		User u4 = new User();
		u4.setName("Pam Halpert");
		u4.setAge(38);
		u4.setBirthday("03/25/1979");
		u4.setAddress("1725 Slough Avenue");
		u4.setAddress2("Scranton, PA 18540");
		u4.setVIP(false);
		u4.setUsername("Beesly");
		u4.setPassword("123456789");
		u4.setPhone("(800)964-DMPC");
		u4.setUserID(12345);

		
		User u5 = new User();
		u5.setName("Andy Bernard");
		u5.setAge(44);
		u5.setBirthday("01/01/1973");
		u5.setAddress("1725 Slough Avenue");
		u5.setAddress2("Scranton, PA 18540");
		u5.setVIP(false);
		u5.setUsername("NardDog");
		u5.setPassword("123456789");
		u5.setPhone("(800)964-DMPC");
		u5.setUserID(12345);

		
		User u6 = new User();
		u6.setName("Angela Schrute");
		u6.setAge(40);
		u6.setBirthday("01/01/1977");
		u6.setAddress("1725 Slough Avenue");
		u6.setAddress2("Scranton, PA 18540");
		u6.setVIP(false);
		u6.setUsername("CatLady");
		u6.setPassword("123456789");
		u6.setPhone("(800)964-DMPC");
		u6.setUserID(12345);

		
		User u7 = new User();
		u7.setName("Creed Bratton");
		u7.setAge(92);
		u7.setBirthday("11/01/1925");
		u7.setAddress("1725 Slough Avenue");
		u7.setAddress2("Scranton, PA 18540");
		u7.setVIP(true);
		u7.setUsername("joker");
		u7.setPassword("1");
		u7.setPhone("(800)964-DMPC");
		u7.setUserID(12345);

		
		// Initialization Accounts // 
		
		Checking c1 = new Checking();
		c1.setAccountNumber(12345678);
		c1.setBalance(5432.10);
		c1.setPin(1234);
		
		Checking a2 = new Checking();
		a2.setAccountNumber(12003400);
		a2.setBalance(9999.99);
		a2.setPin(1234);
		
		Checking a3 = new Checking();
		a3.setAccountNumber(23003456);
		a3.setBalance(1234.56);
		a3.setPin(1234);
		
		Saving s1 = new Saving();
		s1.setAccountNumber(11111111);
		s1.setBalance(9999);
		s1.setPin(2345);
		
		Saving s2 = new Saving();
		s2.setAccountNumber(11111111);
		s2.setBalance(12000);
		s2.setPin(1234);
		
		// Adding Accounts to Users******//
		
		/*u1.getAccountList().add(a1);
		u2.getAccountList().add(a1);
		u3.getAccountList().add(a3);
		u4.getAccountList().add(a3);
		u5.getAccountList().add(a3);
		u6.getAccountList().add(a3);
		u7.getAccountList().add(a2);
		*/
		
		u1.setCheckingAccount(c1);
		u2.setCheckingAccount(c1);
		u3.setCheckingAccount(c1);
		u4.setCheckingAccount(a3);
		u5.setCheckingAccount(a3);
		u6.setCheckingAccount(a3);
		u7.setCheckingAccount(a2);
		
		u1.setSavingAccount(s1);
		u2.setSavingAccount(s1);
		u3.setSavingAccount(s1);
		u4.setSavingAccount(s1);
		u5.setSavingAccount(s1);
		u6.setSavingAccount(s1);
		u7.setSavingAccount(s2);

		
		// Adding Users to the ATM******//
		atm.getUserList().add(u1);
		atm.getUserList().add(u2);
		atm.getUserList().add(u3);
		atm.getUserList().add(u4);
		atm.getUserList().add(u5);
		atm.getUserList().add(u6);
		atm.getUserList().add(u7);

		//ATM.saveData(atm);
	
		
		
		
	//AtmGui atm; 
	//User u1 = new User();
	AtmLogin login = new AtmLogin(atm);
	//AtmRegister reg = new AtmRegister(atm);
	
	
	//atm = new AtmGui(u1);
	
	}
}
