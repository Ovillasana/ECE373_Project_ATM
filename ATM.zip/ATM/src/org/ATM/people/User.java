package org.ATM.people;

import java.io.Serializable;
import java.util.ArrayList;

import org.ATM.software.Account;
import org.ATM.software.Checking;
import org.ATM.software.Saving;

public class User implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private int userID;
	private int age;
	private String birthday;
	private String address;
	private String address2;
	private boolean VIP;
	private String username;
	private String password;
	private String phone;
	//private ArrayList<Account> accountList = new ArrayList<Account>();
	private Checking checkingAccount = new Checking();
	private Saving savingAccount = new Saving();

	
	public User() {
		this.name = "Unknown";
		this.username = "Unknown";
		this.password = "Unknown";
		this.phone = "(520)123-4567";
		this.age = 0;
		this.birthday = "day/month/year";
		this.address = "Unknown";
		this.VIP = false;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Checking getCheckingAccount() {
		return checkingAccount;
	}

	public void setCheckingAccount(Checking account) {
		this.checkingAccount = account;
	}

	public Saving getSavingAccount() {
		return savingAccount;
	}

	public void setSavingAccount(Saving account) {
		this.savingAccount = account;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getBirthday() {
		return birthday;
	}

	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public boolean isVIP() {
		return VIP;
	}

	public void setVIP(boolean vIP) {
		VIP = vIP;
	}
	
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	
	public String getPassword() {
		return password;
	}

	public void setPassword(String pw) {
		this.password = pw;
	}
	

	public String getPhone() {
		return phone;
	}

	public void setPhone(String ph) {
		this.phone = ph;
	}

	public String getAddress2() {
		return address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}
	
	
}
